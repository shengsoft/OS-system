This data set is made up of 30 fragment for each of 3 image files

1:  car2.png     height: 300, width: 450
2:  clown.png    height: 200, width: 320
3:  Renoir.png   height: 400, width: 480


This data set is made up of 300 fragment for each of 3 image files

1:  551878.jpg           height: 1440, width: 2560
2:  google_maps_2.jpg    height: 1080, width: 1920
3:  satellite.jpg        height: 3032, width: 2008

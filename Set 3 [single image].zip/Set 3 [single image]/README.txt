This data set is made up of 100 fragment for a single image file

1:  Renoir.png   height: 400, width: 480

